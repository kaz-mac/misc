(function () {
  'use strict';

  /** @type {WeakSet<Element>} */
  const processed = new WeakSet();
  let scheduled = false;

  function unlockDocumentInteraction() {
    const html = document.documentElement;
    const body = document.body;
    if (!body) return;

    const unlockEl = (el) => {
      const s = el.style;
      if (s.overflow === 'hidden' || s.overflow === 'clip') s.removeProperty('overflow');
      if (s.position === 'fixed') {
        s.removeProperty('position');
        s.removeProperty('top');
        s.removeProperty('left');
        s.removeProperty('width');
        s.removeProperty('height');
      }
      s.removeProperty('pointer-events');
      s.removeProperty('touch-action');
      s.removeProperty('padding-right');
    };

    unlockEl(html);
    unlockEl(body);

    body.classList.remove(
      'modal-open',
      'overflow-hidden',
      'cdk-global-scrollblock',
      'ng-scroll-disabled'
    );
    html.classList.remove('modal-open', 'overflow-hidden', 'ng-scroll-disabled');

    body.removeAttribute('data-scroll-locked');
  }

  function parseZIndex(el) {
    const z = parseInt(getComputedStyle(el).zIndex, 10);
    return Number.isFinite(z) ? z : 0;
  }

  function effectiveZIndex(el) {
    let z = parseZIndex(el);
    let node = el.parentElement;
    while (node && node !== document.documentElement) {
      const pz = parseZIndex(node);
      if (pz > z) z = pz;
      node = node.parentElement;
    }
    return z;
  }

  function viewportCoverageRatio(el) {
    const r = el.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const ix = Math.max(0, Math.min(r.right, vw) - Math.max(r.left, 0));
    const iy = Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0));
    const inter = ix * iy;
    return inter / (vw * vh);
  }

  function isCustomElementModalTag(el) {
    const name = el.tagName.toLowerCase();
    if (!name.includes('-')) return false;
    return (
      /(^|-)modal(-|$)/i.test(name) ||
      name.endsWith('modal') ||
      name.includes('-dialog-') ||
      name.endsWith('-dialog')
    );
  }

  function isSemanticDialog(el) {
    const role = el.getAttribute('role');
    if (role === 'dialog' || role === 'alertdialog') return true;
    if (el.getAttribute('aria-modal') === 'true') return true;
    return false;
  }

  function classSuggestsOverlay(el) {
    if (!el.classList || !el.classList.length) return false;
    for (const c of el.classList) {
      if (c.length > 48) continue;
      if (/(^|-)(modal|overlay|backdrop|dialog|dim|mask)(-|$)/i.test(c)) return true;
    }
    return false;
  }

  function isFullscreenBlockingLayer(el) {
    if (!(el instanceof HTMLElement)) return false;
    const cs = getComputedStyle(el);
    const pos = cs.position;
    if (pos !== 'fixed' && pos !== 'absolute' && pos !== 'sticky') return false;

    const cov = viewportCoverageRatio(el);
    if (cov < 0.45) return false;

    const z = effectiveZIndex(el);
    const opacity = parseFloat(cs.opacity) || 0;
    const pe = cs.pointerEvents;

    if (isSemanticDialog(el) || isCustomElementModalTag(el)) {
      return cov >= 0.2;
    }

    if (classSuggestsOverlay(el) && cov >= 0.35 && z >= 200) return true;

    if (cov >= 0.85 && z >= 400 && opacity < 0.35 && pe !== 'none') {
      return true;
    }

    if (cov >= 0.9 && z >= 300) return true;

    return false;
  }

  function shouldRemoveAsDialogShell(el) {
    if (!(el instanceof HTMLElement)) return false;
    if (isSemanticDialog(el)) return true;
    if (isCustomElementModalTag(el)) return true;
    return false;
  }

  function removeElement(el) {
    if (processed.has(el)) return;
    processed.add(el);
    el.remove();
    unlockDocumentInteraction();
  }

  function walkTree(root, visitor) {
    if (!(root instanceof Element)) return;
    visitor(root);
    if (root.shadowRoot) {
      for (const n of root.shadowRoot.querySelectorAll('*')) {
        if (n instanceof Element) visitor(n);
      }
    }
    for (const child of root.children) {
      walkTree(child, visitor);
    }
  }

  function sweepNode(subtreeRoot) {
    if (!(subtreeRoot instanceof Element)) return;

    /** @type {Set<Element>} */
    const candidates = new Set();

    walkTree(subtreeRoot, (el) => {
      if (processed.has(el)) return;
      if (shouldRemoveAsDialogShell(el)) {
        const cov = viewportCoverageRatio(el);
        const r = el.getBoundingClientRect();
        const bigEnough = r.width >= 120 && r.height >= 80;
        if (cov >= 0.06 || isFullscreenBlockingLayer(el) || bigEnough) {
          candidates.add(el);
        }
        return;
      }
      if (isFullscreenBlockingLayer(el)) {
        candidates.add(el);
      }
    });

    const roots = [...candidates].filter((el) => {
      let p = el.parentElement;
      while (p) {
        if (candidates.has(p)) return false;
        p = p.parentElement;
      }
      return true;
    });

    for (const el of roots) {
      if (el.isConnected && !processed.has(el)) {
        removeElement(el);
      }
    }
  }

  function scheduleSweep(target) {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      try {
        if (target instanceof Element) sweepNode(target);
        else sweepNode(document.documentElement);
      } catch (_) {
        /* ignore */
      }
      unlockDocumentInteraction();
    });
  }

  const observer = new MutationObserver((records) => {
    for (const rec of records) {
      if (rec.type === 'attributes' && rec.target instanceof Element) {
        if (rec.attributeName === 'style' || rec.attributeName === 'class') {
          scheduleSweep(rec.target);
        }
      }
      if (rec.addedNodes && rec.addedNodes.length) {
        rec.addedNodes.forEach((n) => {
          if (n instanceof Element) scheduleSweep(n);
        });
      }
    }
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style', 'class']
  });

  scheduleSweep(document.documentElement);

  window.setInterval(() => {
    unlockDocumentInteraction();
    sweepNode(document.documentElement);
  }, 800);
})();
